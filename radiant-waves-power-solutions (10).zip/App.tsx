
import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/pages/HomePage';
import BlogList from './components/pages/BlogList';
import SinglePost from './components/pages/SinglePost';

const App: React.FC = () => {
  const [route, setRoute] = useState(window.location.hash);

  useEffect(() => {
    const handleHashChange = () => {
      setRoute(window.location.hash);
      window.scrollTo(0, 0);
    };

    window.addEventListener('hashchange', handleHashChange);
    // Set initial route
    handleHashChange();

    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  const renderPage = () => {
    if (route.startsWith('#/blog/')) {
      const postId = route.substring(7);
      return <SinglePost postId={postId} />;
    }
    if (route === '#/blog') {
      return <BlogList />;
    }
    return <HomePage />;
  };

  return (
    <div className="bg-gray-900 text-gray-100 min-h-screen">
      <Header />
      <main>{renderPage()}</main>
      <Footer />
    </div>
  );
};

export default App;
