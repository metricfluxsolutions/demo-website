import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-gray-800">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-yellow-400">About Radiant Waves</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-3xl font-semibold text-white">Who We Are</h3>
            <p className="text-gray-300 leading-relaxed">
              Radiant Waves Power Solutions is a dynamic solar energy company specializing in complete solar power installations and services for residential, commercial, and industrial applications. Headquartered in Kasaragod, we are dedicated to making clean, renewable energy a practical and affordable choice for everyone.
            </p>
             <p className="text-gray-300 leading-relaxed">
              We believe solar power isn’t just a technology—it’s a movement toward a brighter, cleaner, and more self-reliant future. That’s why we not only install systems but also educate and empower our customers to make informed choices that benefit both their wallets and the environment.
            </p>
          </div>
          <div>
            <img src="https://drive.google.com/uc?export=view&id=13wobPZeocMZy3l8RVLVD2bVMAC747anb" alt="A team of professionals planning a solar project" className="rounded-lg shadow-xl w-full h-auto object-cover" />
          </div>
        </div>

        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="bg-gray-900 p-8 rounded-lg shadow-xl">
            <h4 className="text-2xl font-bold mb-4 text-yellow-500">Our Vision</h4>
            <p className="text-gray-300">
              To become a trusted leader in solar energy solutions by driving sustainable growth, empowering energy independence, and contributing to a greener planet through innovative, affordable, and reliable solar technologies.
            </p>
          </div>
          <div className="bg-gray-900 p-8 rounded-lg shadow-xl">
            <h4 className="text-2xl font-bold mb-4 text-yellow-500">Our Mission</h4>
            <p className="text-gray-300">
              At Radiant Waves Power Solutions, our mission is to transform the way energy is produced and consumed by providing end-to-end solar solutions that are efficient, eco-friendly, and accessible to all. We are committed to delivering quality, personalized solutions and building lasting relationships.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;