
import React from 'react';

const QuoteIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M13 14.725c0-5.141 3.892-10.519 10-11.725l.984 2.126c-2.215.835-4.163 3.742-4.38 5.746 2.491.392 4.396 2.547 4.396 5.149 0 3.182-2.584 4.979-5.199 4.979-3.015 0-5.801-2.305-5.801-6.275zm-13 0c0-5.141 3.892-10.519 10-11.725l.984 2.126c-2.215.835-4.163 3.742-4.38 5.746 2.491.392 4.396 2.547 4.396 5.149 0 3.182-2.584 4.979-5.199 4.979-3.015 0-5.801-2.305-5.801-6.275z" />
    </svg>
);

const testimonials = [
    {
        quote: "The team at Radiant Waves was professional from start to finish. They explained everything clearly, installed our solar panels efficiently, and our electricity bills have been significantly reduced. Highly recommended!",
        name: "Rajesh Kumar",
        title: "Homeowner"
    },
    {
        quote: "As a small business owner, I was looking for ways to reduce operational costs. Radiant Waves designed a custom solar solution that has cut our energy expenses by 70%. Their ongoing support has been exceptional.",
        name: "Priya Nair",
        title: "Business Owner"
    }
];

const Testimonials: React.FC = () => {
    return (
        <section id="testimonials" className="py-20 bg-gray-900">
            <div className="container mx-auto px-6">
                <h2 className="text-4xl font-bold text-center mb-4 text-yellow-400">What Our Clients Say</h2>
                <p className="text-lg text-gray-400 text-center mb-12 max-w-3xl mx-auto">
                    Hear from our satisfied customers about their experience with Radiant Waves Solar Solutions.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {testimonials.map((testimonial, index) => (
                        <div key={index} className="bg-gray-800 p-8 rounded-lg shadow-lg flex flex-col justify-between transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-yellow-400/20">
                            <div>
                                <QuoteIcon className="w-8 h-8 text-yellow-500 mb-4" />
                                <p className="text-gray-300 italic text-lg mb-6">"{testimonial.quote}"</p>
                            </div>
                            <div className="text-right">
                                <p className="font-bold text-xl text-white">{testimonial.name}</p>
                                <p className="text-yellow-400">{testimonial.title}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Testimonials;
