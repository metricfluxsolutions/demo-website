
import React from 'react';
import Hero from '../Hero';
import About from '../About';
import Services from '../Services';
import WhyChooseUs from '../WhyChooseUs';
import Gallery from '../Gallery';
import Testimonials from '../Testimonials';
import Contact from '../Contact';
import BlogPreview from '../BlogPreview';

const HomePage: React.FC = () => {
  return (
    <>
      <Hero />
      <About />
      <Services />
      <WhyChooseUs />
      <Gallery />
      <BlogPreview />
      <Testimonials />
      <Contact />
    </>
  );
};

export default HomePage;
