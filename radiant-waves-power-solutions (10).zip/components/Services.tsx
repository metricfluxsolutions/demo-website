
import React from 'react';

const SolarPanelIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M4 6 3 14h18l-1-8H4Z"></path><path d="m3 14 9 6 9-6"></path><path d="M6 6.5 12 10l6-3.5"></path>
        <path d="M8 14.5v-5"></path><path d="M16 14.5v-5"></path><path d="m12 16.5-3-1.7"></path><path d="m12 16.5 3-1.7"></path>
    </svg>
);

const BatteryIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <rect width="16" height="10" x="2" y="7" rx="2" ry="2"></rect><line x1="22" x2="22" y1="11" y2="13"></line>
        <line x1="6" x2="6" y1="11" y2="13"></line><line x1="10" x2="10" y1="11" y2="13"></line>
    </svg>
);

const DropletIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"></path>
    </svg>
);

const WrenchIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path>
    </svg>
);

const PenToolIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="m12 19 7-7 3 3-7 7-3-3z"></path><path d="m18 13-1.5-7.5L2 2l3.5 14.5L13 18z"></path>
        <path d="m2 2 7.586 7.586"></path><path d="m11 13 2.5 2.5"></path>
    </svg>
);

const services = [
  {
    icon: <SolarPanelIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Solar Panel Installation',
    description: 'Expert installation of On-grid, Off-grid & Hybrid systems for homes and businesses.',
  },
  {
    icon: <BatteryIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Inverter & Battery Setup',
    description: 'Reliable setup of inverters and battery storage for uninterrupted power supply.',
  },
  {
    icon: <DropletIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Solar Water Heaters',
    description: 'Eco-friendly and cost-effective solar water heating solutions for all your needs.',
  },
  {
    icon: <WrenchIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Maintenance & Monitoring',
    description: 'Comprehensive maintenance services and performance monitoring to maximize your investment.',
  },
  {
    icon: <PenToolIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Custom Project Design',
    description: 'Personalized solar consultation and project design to meet your unique energy requirements.',
  },
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-yellow-400">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-gray-800 p-8 rounded-lg shadow-lg text-center transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-yellow-400/20">
              <div className="flex justify-center">{service.icon}</div>
              <h3 className="text-2xl font-semibold mb-3 text-white">{service.title}</h3>
              <p className="text-gray-400 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
