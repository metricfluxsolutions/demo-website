
import React, { useState, useEffect } from 'react';

interface Post {
  id: string;
  title: string;
  author: string;
  date: string;
  summary: string;
  featuredImage: string;
  content: string;
}

interface SinglePostProps {
  postId: string;
}

const SinglePost: React.FC<SinglePostProps> = ({ postId }) => {
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        setLoading(true);
        const response = await fetch('./data/blog.json');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const posts: Post[] = await response.json();
        const foundPost = posts.find(p => p.id === postId);
        setPost(foundPost || null);
      } catch (e: any) {
        setError(e.message);
        console.error("Failed to fetch post:", e);
      } finally {
        setLoading(false);
      }
    };
    fetchPost();
  }, [postId]);

  if (loading) {
    return (
      <div className="py-40 text-center">
        <h2 className="text-3xl font-bold text-white">Loading Post...</h2>
      </div>
    );
  }

  if (error) {
    return (
      <div className="py-40 text-center">
        <h2 className="text-3xl font-bold text-red-500">Error loading post</h2>
        <p className="text-gray-400 mt-4">{error}</p>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="py-40 text-center">
        <h2 className="text-3xl font-bold text-white">Post not found</h2>
        <p className="text-gray-400 mt-4">The article you are looking for does not exist.</p>
        <a href="#/blog" className="mt-8 inline-block bg-yellow-500 text-gray-900 font-bold py-3 px-8 rounded-full hover:bg-yellow-400">
          Back to Blog
        </a>
      </div>
    );
  }

  return (
    <article className="py-24 sm:py-32 bg-gray-900 text-white">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <header className="mb-12 text-center">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-yellow-400 leading-tight">{post.title}</h1>
            <div className="mt-6 text-md text-gray-400">
              <span>By {post.author}</span> &bull; <span>{new Date(post.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
            </div>
          </header>

          <figure className="mb-12">
            <img src={post.featuredImage} alt={post.title} className="w-full h-auto rounded-lg shadow-xl object-cover" />
          </figure>

          <div 
            className="prose prose-invert prose-lg max-w-none prose-p:text-gray-300 prose-headings:text-yellow-400 prose-strong:text-white prose-a:text-yellow-500 hover:prose-a:text-yellow-400"
            dangerouslySetInnerHTML={{ __html: post.content }} 
          />
          
          <div className="mt-16 border-t border-gray-700 pt-8 text-center">
            <a href="#/blog" className="text-yellow-500 hover:text-yellow-400 font-semibold">&larr; Back to all posts</a>
          </div>
        </div>
      </div>
    </article>
  );
};

export default SinglePost;
