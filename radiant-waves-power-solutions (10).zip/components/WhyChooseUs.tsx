
import React from 'react';

const BadgeCheckIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M3.85 8.62a4 4 0 0 1 4.78-4.78l.22.04.14.02 6.38 1.94 2.72.82a4 4 0 0 1 3.34 4.54l-.27 1.1a4 4 0 0 1-4.78 4.78l-.22-.04-.14-.02-6.38-1.94-2.72-.82a4 4 0 0 1-3.34-4.54l.27-1.1Z" />
        <path d="m9 12 2 2 4-4" />
    </svg>
);

const SettingsIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 0 2l-.15.08a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1 0-2l.15-.08a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"></path>
        <circle cx="12" cy="12" r="3"></circle>
    </svg>
);

const HistoryIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
        <path d="M3 3v5h5" />
        <path d="M12 7v5l4 2" />
    </svg>
);

const DollarSignIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <line x1="12" x2="12" y1="2" y2="22"></line>
        <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
    </svg>
);


const reasons = [
  {
    icon: <BadgeCheckIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Certified Professionals',
    description: 'Our team consists of certified engineers and solar professionals who bring precision and expertise to every project.',
  },
  {
    icon: <SettingsIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Customized Solutions',
    description: "We understand that each client's energy needs are unique—our solutions are tailored to deliver maximum efficiency.",
  },
  {
    icon: <HistoryIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Continuous Support',
    description: "Our work doesn't end after installation—we offer ongoing support, maintenance, and upgrades for years to come.",
  },
  {
    icon: <DollarSignIcon className="w-12 h-12 mb-4 text-yellow-400" />,
    title: 'Cost-Effective',
    description: 'We provide affordable solutions that deliver long-term savings and excellent return on investment.',
  },
];

const WhyChooseUs: React.FC = () => {
  return (
    <section id="why-choose-us" className="py-20 bg-gray-800">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-yellow-400">Why Choose Us?</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <div key={index} className="bg-gray-900 p-8 rounded-lg shadow-lg text-center flex flex-col items-center transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-yellow-400/20">
              <div className="flex-shrink-0">{reason.icon}</div>
              <h3 className="text-2xl font-semibold mt-4 mb-3 text-white">{reason.title}</h3>
              <p className="text-gray-400 leading-relaxed">{reason.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;
