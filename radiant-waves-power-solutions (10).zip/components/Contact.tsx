
import React, { useState } from 'react';

const PhoneIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
    </svg>
);
const MailIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <rect width="20" height="16" x="2" y="4" rx="2"></rect><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
    </svg>
);
const MapPinIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle>
    </svg>
);
const WhatsappIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className={className}>
       <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.79.46 3.48 1.31 4.96L2 22l5.34-1.38c1.42.84 3.04 1.32 4.7 1.32h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.73-1.11-5.19-2.9-7C17.23 3.11 14.77 2 12.04 2zM9.54 8.5c.2-.47.4-.53.54-.53.18 0 .38.01.53.01s.44.2.68.68c.24.48.81 1.97.91 2.12.1.15.19.24.04.38-.14.15-.33.24-.47.38-.15.15-.3.17-.44.12-.15-.05-.96-.35-1.82-1.1c-.69-.58-1.14-1.3-1.28-1.52-.14-.22-.01-.34.12-.47.11-.11.25-.29.35-.41.1-.12.15-.2.22-.32.07-.12.04-.25-.02-.37-.06-.12-.56-1.34-.76-1.81z"/>
    </svg>
);

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', message: '' });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  // --- Backend Connection Setup ---

  // ** IMPORTANT **
  // This is the URL for the Google Apps Script that will act as our backend.
  // You must create your own script and replace this placeholder.
  // Full instructions are in the comment block below.
  const GOOGLE_APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwRz8St9ymgwB4KzKbErtsY-phP56wVG-xEldbXO5ihbxS93gKt37ehMv1mCPZSdA5IhQ/exec';

  /*
    --- How to Connect Your Form to Google Sheets ---

    1. CREATE A GOOGLE SHEET:
       - Go to sheets.google.com and create a new blank spreadsheet.
       - You can name it "Radiant Waves Queries".
       - Create a header row in the first sheet with these exact column names:
         Timestamp, Name, Email, Phone, Message

    2. OPEN THE APPS SCRIPT EDITOR:
       - In your new sheet, go to "Extensions" > "Apps Script".
       - A new script project will open. Delete any existing code in the `Code.gs` file.

    3. PASTE THE SCRIPT:
       - Copy the complete code below and paste it into the `Code.gs` editor.

       function doPost(e) {
         try {
           // Get the sheet by its name. Make sure it matches the name of your sheet tab.
           var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Sheet1");
           
           var params = e.parameter;
           var newRow = [
             new Date(),
             params.name,
             params.email,
             params.phone,
             params.message
           ];
           
           sheet.appendRow(newRow);
           
           // Return a success response (required for CORS)
           return ContentService
             .createTextOutput(JSON.stringify({ "result": "success", "data": JSON.stringify(params) }))
             .setMimeType(ContentService.MimeType.JSON);

         } catch (error) {
           // Return a detailed error message for debugging
           return ContentService
             .createTextOutput(JSON.stringify({ "result": "error", "error": error.toString() }))
             .setMimeType(ContentService.MimeType.JSON);
         }
       }

    4. DEPLOY THE SCRIPT:
       - Click the "Deploy" button at the top right.
       - Select "New deployment".
       - For "Select type", click the gear icon and choose "Web app".
       - In the "New deployment" dialog:
         - Description: "Contact Form API"
         - Execute as: "Me"
         - Who has access: "Anyone" (This is crucial for a public form to work)
       - Click "Deploy".

    5. AUTHORIZE AND GET URL:
       - Google will ask you to authorize the script. Follow the prompts. You may need to
         click "Advanced" and "Go to... (unsafe)" to proceed. This is standard for new scripts.
       - After deploying, copy the "Web app URL".
       - Paste this URL into the `GOOGLE_APPS_SCRIPT_URL` constant above.
  */

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('loading');
    setErrorMessage('');

    if (GOOGLE_APPS_SCRIPT_URL.includes('YOUR_GOOGLE_APPS_SCRIPT_URL_HERE')) {
      const devError = 'This form is not yet active. Please follow the setup instructions in the components/Contact.tsx file.';
      console.error("Form submission failed:", devError);
      setErrorMessage(devError);
      setStatus('error');
      return;
    }
    
    const form = e.target as HTMLFormElement;
    const formDataPayload = new FormData(form);

    try {
      // The 'no-cors' mode is a "fire-and-forget" approach. We won't get a response back,
      // but it's effective for simple Google Apps Script backends to avoid CORS issues.
      await fetch(GOOGLE_APPS_SCRIPT_URL, {
        method: 'POST',
        body: formDataPayload,
        mode: 'no-cors'
      });
      
      // Since we can't read the response in 'no-cors' mode, we optimistically assume success
      // if the fetch call itself doesn't throw a network error.
      setStatus('success');
      setFormData({ name: '', email: '', phone: '', message: '' });

    } catch (error) {
      console.error('Error submitting form:', error);
      setErrorMessage('A network error occurred. Could not send your message. Please try again.');
      setStatus('error');
    }
  };

  return (
    <section id="contact" className="py-20 bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-yellow-400">Get In Touch</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="bg-gray-800 p-8 rounded-lg shadow-lg">
            <h3 className="text-3xl font-semibold text-white mb-6">Contact Information</h3>
            <div className="space-y-6 text-gray-300">
              <div className="flex items-start space-x-4">
                <MapPinIcon className="w-6 h-6 mt-1 text-yellow-400 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-white">Office Address</h4>
                  <p>First Floor, Oppo. New Bustand, Alamippally, Kanhangad, Kasaragod, Kerala</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <PhoneIcon className="w-6 h-6 text-yellow-400 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-white">Phone</h4>
                  <p>+91 8592063738, +91 7592063738</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <MailIcon className="w-6 h-6 text-yellow-400 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-white">Email</h4>
                  <a href="mailto:Info@radiantwaves.org" className="hover:text-yellow-400">Info@radiantwaves.org</a>
                </div>
              </div>
              <div>
                <h4 className="font-bold text-white mb-2">Working Area</h4>
                <p>Kannur & Kasaragod</p>
              </div>
              <a href="https://wa.me/918592063738" target="_blank" rel="noopener noreferrer" 
                className="inline-flex items-center space-x-2 bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors">
                <WhatsappIcon className="w-6 h-6" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-gray-800 p-8 rounded-lg shadow-lg">
            <h3 className="text-3xl font-semibold text-white mb-6">Send Us a Query</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="sr-only">Your Name</label>
                <input id="name" type="text" name="name" placeholder="Your Name" value={formData.name} onChange={handleChange} required className="w-full p-3 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
              </div>
              <div>
                <label htmlFor="email" className="sr-only">Your Email</label>
                <input id="email" type="email" name="email" placeholder="Your Email" value={formData.email} onChange={handleChange} required className="w-full p-3 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
              </div>
              <div>
                <label htmlFor="phone" className="sr-only">Your Phone (Optional)</label>
                <input id="phone" type="tel" name="phone" placeholder="Your Phone (Optional)" value={formData.phone} onChange={handleChange} className="w-full p-3 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-yellow-500" />
              </div>
              <div>
                <label htmlFor="message" className="sr-only">Your Message</label>
                <textarea id="message" name="message" placeholder="Your Message" rows={5} value={formData.message} onChange={handleChange} required className="w-full p-3 bg-gray-700 text-white rounded-md border border-gray-600 focus:outline-none focus:ring-2 focus:ring-yellow-500"></textarea>
              </div>
              <button type="submit" disabled={status === 'loading'} className="w-full bg-yellow-500 text-gray-900 font-bold py-3 px-8 rounded-md hover:bg-yellow-400 transition-all duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed">
                {status === 'loading' ? 'Sending...' : 'Submit Query'}
              </button>
              {status === 'success' && <p className="text-green-400 text-center mt-4" role="alert">Thank you! Your message has been sent successfully.</p>}
              {status === 'error' && (
                <p className="text-red-400 text-center mt-4" role="alert">
                  {errorMessage || 'Something went wrong. Please try again later.'}
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
