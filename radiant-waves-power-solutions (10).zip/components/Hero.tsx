
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="hero-bg h-screen flex items-center justify-center text-white text-center">
      <div className="container mx-auto px-6">
        <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-4 animate-fade-in-down" style={{ animationDelay: '0.2s' }}>
          🌞 Welcome to Radiant Waves Solar Solutions
        </h1>
        <p className="text-lg md:text-2xl mb-8 font-light animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
          Brightening Lives with Smarter Solar Power.
        </p>
        <div className="animate-fade-in-up" style={{ animationDelay: '0.8s' }}>
          <a
            href="#contact"
            className="bg-yellow-500 text-gray-900 font-bold py-3 px-8 rounded-full hover:bg-yellow-400 transition-all duration-300 transform hover:scale-105"
          >
            Get a Free Quote
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
