
import React from 'react';
import posts from '../../data/blog.json';

const BlogList: React.FC = () => {
  return (
    <div className="py-24 sm:py-32 bg-gray-900">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-4xl font-bold tracking-tight text-yellow-400 sm:text-5xl">From the Blog</h2>
          <p className="mt-4 text-lg leading-8 text-gray-300">
            Stay updated with the latest news, insights, and innovations in the solar industry.
          </p>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-x-8 gap-y-16 border-t border-gray-700 pt-16 sm:mt-20 sm:pt-20 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {posts.map((post) => (
            <a href={`#/blog/${post.id}`} key={post.id} className="flex max-w-xl flex-col items-start justify-between group rounded-lg p-6 transition-all duration-300 hover:bg-gray-800">
              <div className="relative w-full">
                <img src={post.featuredImage} alt={post.title} className="aspect-[16/9] w-full rounded-2xl bg-gray-100 object-cover sm:aspect-[2/1] lg:aspect-[3/2]" />
                <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" />
              </div>
              <div className="mt-6 w-full">
                <div className="flex items-center gap-x-4 text-xs">
                  <time dateTime={post.date} className="text-gray-400">
                    {new Date(post.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                  </time>
                </div>
                <div className="relative">
                  <h3 className="mt-3 text-xl font-semibold leading-6 text-white group-hover:text-yellow-400">
                    {post.title}
                  </h3>
                  <p className="mt-5 text-sm leading-6 text-gray-400">{post.summary}</p>
                </div>
                 <div className="relative mt-6 flex items-center gap-x-4">
                  <div className="text-sm leading-6">
                    <p className="font-semibold text-white">
                      By <span className="text-yellow-400">{post.author}</span>
                    </p>
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogList;
