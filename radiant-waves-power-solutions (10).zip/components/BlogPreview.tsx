
import React, { useState, useEffect } from 'react';

interface Post {
  id: string;
  title: string;
  author: string;
  date: string;
  summary: string;
  featuredImage: string;
  content: string;
}

const BlogPreview: React.FC = () => {
  const [latestPosts, setLatestPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await fetch('./data/blog.json');
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const posts: Post[] = await response.json();
        // Assuming posts are sorted newest first in the JSON
        setLatestPosts(posts.slice(0, 3));
      } catch (e: any) {
        setError(e.message);
        console.error("Failed to fetch blog posts:", e);
      } finally {
        setLoading(false);
      }
    };
    fetchPosts();
  }, []);

  if (loading) {
    return (
      <section id="blog-preview" className="py-20 bg-gray-800">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-2xl font-semibold text-white">Loading Latest News...</h2>
        </div>
      </section>
    );
  }

  if (error) {
    // Optionally render an error message, or just don't render the section
    return null;
  }
  
  if (latestPosts.length === 0) {
    return null; // Don't render anything if there are no posts
  }

  return (
    <section id="blog-preview" className="py-20 bg-gray-800">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-yellow-400">Latest News</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {latestPosts.map((post) => (
            <a href={`#/blog/${post.id}`} key={post.id} className="block group bg-gray-900 rounded-lg shadow-lg overflow-hidden transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-yellow-400/20">
              <div className="relative h-56">
                <img src={post.featuredImage} alt={post.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-6">
                <p className="text-sm text-yellow-400 mb-2">{new Date(post.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-yellow-400 transition-colors">{post.title}</h3>
                <p className="text-gray-400 leading-relaxed mb-4">{post.summary}</p>
                <span className="font-semibold text-yellow-500 group-hover:text-yellow-300">Read More &rarr;</span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BlogPreview;
