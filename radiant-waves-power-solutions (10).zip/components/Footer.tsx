
import React from 'react';

const InstagramIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
    </svg>
);

const FacebookIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
    </svg>
);

const XIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
    </svg>
);


const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-gray-900 border-t border-gray-700">
      <div className="container mx-auto px-6 py-8 text-center text-gray-400">
        <div className="flex justify-center items-center space-x-6 mb-4">
            <a href="#" aria-label="Facebook" className="text-gray-400 hover:text-yellow-400 transition-colors duration-300">
                <FacebookIcon className="w-6 h-6"/>
            </a>
            <a href="https://www.instagram.com/radiant_.waves?igsh=NzVsd3VrbXN3MTdw" target="_blank" rel="noopener noreferrer" aria-label="Instagram" className="text-gray-400 hover:text-yellow-400 transition-colors duration-300">
                <InstagramIcon className="w-6 h-6"/>
            </a>
            <a href="#" aria-label="X" className="text-gray-400 hover:text-yellow-400 transition-colors duration-300">
                <XIcon className="w-6 h-6"/>
            </a>
        </div>
        <p className="mb-2">
          &copy; {currentYear} Radiant Waves Solar Solutions. All Rights Reserved.
        </p>
        <p>Developed by Metric Flux Solutions Pvt Ltd</p>
      </div>
    </footer>
  );
};

export default Footer;
