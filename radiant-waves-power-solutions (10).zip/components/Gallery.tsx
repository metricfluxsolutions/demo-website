import React, { useState } from 'react';

const images = [
  { id: 1, src: 'https://drive.google.com/uc?export=view&id=14DkRiquLPdNy4fRwTa2gdjWTta_YSXBC', alt: 'Technician installing solar panels on a rooftop' },
  { id: 2, src: 'https://drive.google.com/uc?export=view&id=1cJ1mXcKJqZ9g7mTK6PImSjfyCs_x-ecp', alt: 'Modern residential house with solar panels' },
  { id: 3, src: 'https://drive.google.com/uc?export=view&id=11dA7mSbcTWfHnUya9HAoD9rv1NUrQ2xX', alt: 'Solar panels on a city building rooftop' },
  { id: 4, src: 'https://drive.google.com/uc?export=view&id=1_gXSRR71bIxiXUskMbScyax-3kcRBRx2', alt: 'Large solar farm under a clear sky' },
  { id: 5, src: 'https://drive.google.com/uc?export=view&id=13wobPZeocMZy3l8RVLVD2bVMAC747anb', alt: 'Reviewing solar energy performance charts' },
  { id: 6, src: 'https://drive.google.com/uc?export=view&id=1Q4MlLwrG11EWGC0f_I4WbKu9mejflxBj', alt: 'Worker conducting maintenance on solar panels' },
];

const XIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section id="gallery" className="py-20 bg-gray-800">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl font-bold text-center mb-12 text-yellow-400">Our Work</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {images.map((image) => (
            <div key={image.id} className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer" onClick={() => setSelectedImage(image.src)}>
              <img src={image.src} alt={image.alt} className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110" />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-500 flex items-center justify-center">
                <p className="text-white text-lg font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-500 px-4 text-center">{image.alt}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4" onClick={() => setSelectedImage(null)}>
          <div className="relative bg-white rounded-lg max-w-3xl max-h-full" onClick={(e) => e.stopPropagation()}>
            <img src={selectedImage} alt="Enlarged view" className="w-auto h-auto max-w-full max-h-[90vh] object-contain" />
            <button onClick={() => setSelectedImage(null)} className="absolute -top-2 -right-2 text-gray-800 bg-white rounded-full p-1 hover:bg-gray-200 shadow-lg">
              <XIcon className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;